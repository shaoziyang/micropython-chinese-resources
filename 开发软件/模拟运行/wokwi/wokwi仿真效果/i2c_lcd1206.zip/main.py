from machine import Pin, I2C
from time import sleep_ms
from i2c_lcd1602 import I2C_LCD1602

i2c = I2C(0, scl=Pin(1), sda=Pin(0))

LCD = I2C_LCD1602(i2c)

LCD.puts("I2C LCD1602")
n = 0
while 1:
    LCD.puts(n, 0, 1)
    n += 1
    sleep_ms(1000)
