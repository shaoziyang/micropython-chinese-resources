from machine import Pin
from time import sleep_ms
from lcd1602_595 import LCD1602_595

led = Pin(25, Pin.OUT)

lcd = LCD1602_595(ST_CP=Pin(1), SH_CP=Pin(2), DS=Pin(0))

n = 0
while 1:
    lcd.print(f"{n}", end=' ')
    n += 1
    
    sleep_ms(500) 