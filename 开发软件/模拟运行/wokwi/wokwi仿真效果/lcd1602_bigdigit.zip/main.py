import lcd1602_bigdigit
from machine import I2C, Pin
from time import sleep_ms
import random

led = Pin(25, Pin.OUT)
i2c = I2C(0, sda = Pin(0), scl = Pin(1))

lcd = lcd1602_bigdigit.LCD1602_BIGDIGIT(i2c)

fontname = list(lcd1602_bigdigit.BIGFONTS)

n = 0
while 1:
    n+=1
    
    if n%10 == 0:
        led(not led())
        fn = random.randrange(len(fontname))
        lcd.font(fontname[fn])
        print('set font', fontname[fn])
    
    lcd.number(n,4)
    
    sleep_ms(200)     