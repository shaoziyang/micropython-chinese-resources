from machine import Pin
from time import sleep_ms
from neopixel import NeoPixel
from random import randrange as rnd

np = NeoPixel(Pin(0), 16)


def shift(np):
    for i in range(np.n-1):
        np[-i-1] = np[-i-2]
    np[0] = (0,0,0)
        
def main():
    while 1:

        shift(np)
        if rnd(3) == 0:
            np[0] = (rnd(256), rnd(256), rnd(256))
        
        np.write()
        
        sleep_ms(200)

main()
