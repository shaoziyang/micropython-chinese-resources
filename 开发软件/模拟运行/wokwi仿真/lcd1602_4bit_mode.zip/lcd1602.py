from time import sleep_ms
from machine import Pin

class LCD1602():

    def __init__(self, rs, rw, e, d4, d5, d6, d7, bk = None):
        self.rs = rs
        self.rw = rw
        self.e = e
        self.bk = bk
        self.d4 = d4
        self.d5 = d5
        self.d6 = d6
        self.d7 = d7

        self.rs.init(Pin.OUT)
        if self.rw != None:
            self.rw.init(Pin.OUT, value=0)
        self.e.init(Pin.OUT)
        self.d4.init(Pin.OUT)
        self.d5.init(Pin.OUT)
        self.d6.init(Pin.OUT)
        self.d7.init(Pin.OUT)

        for i in [0x33, 0x32, 0x28, 0x0C, 0x06, 0x01]:
            self.setcmd(i)
            sleep_ms(5)
        self.px, self.py = 0, 0
        self.pb = bytearray(16)
        self.version='2.1'
        
    def send(self, dat):
        self.d4.value(dat & 0x10)
        self.d5.value(dat & 0x20)
        self.d6.value(dat & 0x40)
        self.d7.value(dat & 0x80)
        self.e(1)
        sleep_ms(1)
        self.e(0)
        sleep_ms(1)

    def setcmd(self, cmd):
        self.rs(0)
        self.send(cmd)
        self.send(cmd<<4)

    def setdat(self, dat):
        self.rs(1)
        self.send(dat)
        self.send(dat<<4)

    def write_cgram(self, buf, reg=0):
        n = len(buf)
        self.setcmd(0x40 + (reg%8)*8)
        for i in range(n):
            self.setdat(buf[i])

    def clear(self):
        self.setcmd(1)            

    def backlight(self, on):
        if self.bk != None:
            self.bk = on

    def on(self):
        self.setcmd(0x0C)

    def off(self):
        self.setcmd(0x08)

    def shl(self):
        self.setcmd(0x18)

    def shr(self):
        self.setcmd(0x1C)

    def char(self, ch, x=-1, y=0):
        if x>=0:
            a=0x80
            if y>0:
                a=0xC0
            self.setcmd(a+x)
        self.setdat(ch)

    def puts(self, s, x=0, y=0):
        if type(s) is not str:
            s = str(s)
        if len(s)>0:
            self.char(ord(s[0]),x,y)
            for i in range(1, len(s)):
                self.char(ord(s[i]))

    def newline(self):
        self.px = 0
        self.py += 1

    def print(self, s, end='\n'):
        if type(s) is not str:
            s = str(s)
        s = s + end
        for i in range(len(s)):
            d = ord(s[i])
            if d == ord('\n'):
                self.newline()
            elif d == ord('\r'):
                self.px = 0
            else:
                if self.py > 1:
                    self.clear()
                    self.py = 1
                    for j in range(16):
                        self.char(self.pb[j], j)
                        self.pb[j] = 32
			
                self.char(d, self.px, self.py)
                if self.py:
                    self.pb[self.px] = d
                self.px += 1
                if self.px > 15:
                    self.newline()  
