from machine import Pin
from time import sleep_ms
from lcd1602 import LCD1602

led = Pin(25, Pin.OUT)

lcd = LCD1602(Pin(0), Pin(1), Pin(2), Pin(3), Pin(4), Pin(5), Pin(6))

n = 0
while 1:
    lcd.print(f"{n}", end=' ')
    n += 1
    
    sleep_ms(500) 